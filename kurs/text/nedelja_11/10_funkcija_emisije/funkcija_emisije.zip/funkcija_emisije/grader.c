#include <stdio.h>
#include "code.h"

void ispisListe(Emisija *head)
{
    Emisija* tmp = head;
    while(tmp != NULL)
    {
        ispisiEmisiju(tmp);
        tmp = tmp->sledeci;
    }
}

void ispisiEmisiju(Emisija *head)
{
    printf("Ime:%s\n", head->ime);
    printf("Vreme pocetka- %d:%d\n", head->satiPocetno, head->minutiPocetno);
    printf("Vreme zavrsetka- %d:%d\n", head->satiZavrseno, head->minutiZavrseno);
}


void main() {
	int brojEmisija,i;
	scanf("%d", &brojEmisija);
	Emisija *head = NULL;
    char ime[50];
    int satiPocetno, minutiPocetno, satiZavrseno, minutiZavrseno;
    double prosek;
	for (i=0;i<brojEmisija;i++){
		scanf("%s",ime);
		scanf("%d%d",&satiPocetno,&minutiPocetno);
		scanf("%d%d",&satiZavrseno,&minutiZavrseno);
		Emisija* novi= napraviEmisiju(ime,satiPocetno,minutiPocetno,satiZavrseno,minutiZavrseno);
		head = dodajEmisiju(head,novi);

	}
	scanf("%d%d",&sati,&minuti);
	ispisListe(head);
	printf("%d\n",brojEmisijaUTerminu(head,sati,minuti)); 
}
