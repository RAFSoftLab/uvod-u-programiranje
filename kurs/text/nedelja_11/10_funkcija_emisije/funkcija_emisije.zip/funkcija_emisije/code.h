#ifndef __CODE_H__
#define __CODE_H__

typedef struct Emisija
{
    char ime[50];
    int satiPocetno;
    int minutiPocetno;
    int satiZavrseno;
    int minutiZavrseno;
    struct Emisija * sledeci;
} Emisija;

Emisija *dodajEmisiju(Emisija *head,Emisija *novi);
Emisija* napraviEmisiju(char ime[50], int satiPocetno, int minutiPocetno, int satiZavrseno, int minutiZavrseno);
int brojEmisijaUTerminu(Emisija* head, int sati, int minuti);


#endif /* __CODE_H__ */