#ifndef __CODE_H__
#define __CODE_H__

typedef struct Student
{
    char ime[50];
    char prezime[50];
    char indeks[50];
    int brojIndeksa;
    int godinaUpisa;
    double prosek;
    struct Student * sledeci;
} Student;

Student* dodajStudenta(Student* head, Student* novi);
Student* napraviStudenta(char ime[50],char prezime[50],char indeks[50],int brojIndeksa,int godinaUpisa, double prosek);


#endif /* __CODE_H__ */