#include <stdio.h>
#include "code.h"

void ispisListe(Student *head)
{
    Student* tmp = head;
    while(tmp != NULL)
    {
        ispisiStudenta(tmp);
        tmp = tmp->sledeci;
    }
}


void ispisiStudenta(Student *head)
{
    printf("Ime:%s\n", head->ime);
    printf("Prezime:%s\n", head->prezime);
    printf("Indeks:%s\n", head->indeks);
    printf("Broj indeksa:%d\n", head->brojIndeksa);
    printf("Godina upisa:%d\n", head->godinaUpisa);
    printf("Prosek:%.2lf\n", head->prosek);
}


void main() {
	int brojStudenata,i;
	scanf("%d", &brojStudenata);
	Student *head = NULL;
    char ime[50], prezime[50],indeks[50];
    int brojIndeksa, godinaUpisa;
    double prosek;
	for (i=0;i<brojStudenata;i++){
		scanf("%s",ime);
		scanf("%s",prezime);
		scanf("%s",indeks);
		scanf("%d",&brojIndeksa);
		scanf("%d",&godinaUpisa);
		scanf("%lf",&prosek);
		Student* novi= napraviStudenta(ime,prezime,indeks,brojIndeksa,godinaUpisa,prosek);
		head = dodajStudenta(head,novi);
	}
	ispisListe(head);
}
