#include <stdio.h>
#include "code.h"

void ispisListe(Student *head)
{
    Student* tmp = head;
    while(tmp != NULL)
    {
        ispisiStudenta(tmp);
        tmp = tmp->sledeci;
    }
}


void ispisiStudenta(Student *head)
{
    printf("Ime:%s\n", head->ime);
    printf("Prezime:%s\n", head->prezime);
    printf("Indeks:%s\n", head->indeks);
    printf("Broj indeksa:%d\n", head->brojIndeksa);
    printf("Godina upisa:%d\n", head->godinaUpisa);
    printf("Prvi test:%d\n", head->prviTest);
    printf("Drugi test:%d\n", head->drugiTest);
    printf("Prvi kolokvijum:%d\n", head->prviKolokvijum);
    printf("Drugi kolokvijum:%d\n", head->drugiKolokvijum);
    printf("Ispit:%d\n", head->ispit);
}




void main() {
	int brojStudenata,i;
	scanf("%d", &brojStudenata);
	Student *head = NULL;
    char ime[50], prezime[50],indeks[50];
    int brojIndeksa, godinaUpisa, prviTest, drugiTest, prviKolokvijum, drugiKolokvijum, ispit;
    for (i=0;i<brojStudenata;i++){
		scanf("%s",ime);
		scanf("%s",prezime);
		scanf("%s",indeks);
		scanf("%d",&brojIndeksa);
		scanf("%d",&godinaUpisa);
		scanf("%d",&prviTest);
		scanf("%d",&drugiTest);
		scanf("%d",&prviKolokvijum);
		scanf("%d",&drugiKolokvijum);
		scanf("%d",&ispit);
		Student* novi= napraviStudenta(ime,prezime,indeks,brojIndeksa,godinaUpisa, prviTest, drugiTest, prviKolokvijum, drugiKolokvijum, ispit);
		head = dodajStudenta(head,novi);
	}
	ispisListe(head);
}