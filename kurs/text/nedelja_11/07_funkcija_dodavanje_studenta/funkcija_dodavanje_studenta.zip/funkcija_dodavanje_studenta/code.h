#ifndef __CODE_H__
#define __CODE_H__

typedef struct Student
{
    char ime[50];
    char prezime[50];
    char indeks[50];
    int brojIndeksa;
    int godinaUpisa;
    int prviTest;
    int drugiTest;
    int prviKolokvijum;
    int drugiKolokvijum;
    int ispit;
    struct Student * sledeci;
} Student;

Student* dodajStudenta(Student* head, Student* novi);
Student *napraviStudenta(char ime[50],char prezime[50],char indeks[50],int brojIndeksa,int godinaUpisa,int prviTest,int drugiTest,int prviKolokvijum,int drugiKolokvijum, int ispit);


#endif /* __CODE_H__ */