#ifndef __CODE_H__
#define __CODE_H__

int izbaciDeljiveCifre(int a, int k);

#endif /* __CODE_H__ */