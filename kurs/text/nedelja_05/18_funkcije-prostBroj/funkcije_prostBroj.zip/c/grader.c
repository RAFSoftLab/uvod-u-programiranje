#include <stdio.h>
#include "code.h"

void main() {
	int a;
	scanf("%d", &a);
	printf("%d", prostBroj(a));
}