#include <stdio.h>
#include "code.h"

void main() {
	int a,k;
	scanf("%d%d", &a,&k);
	printf("%d", izbaciVeceCifre(a,k));
}